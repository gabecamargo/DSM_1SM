idade = prompt("Insira sua idade:")
idade = parseInt(idade);

if (idade < 18){
    console.log("Menor de idade");
}else{
    console.log("Maior de idade");
}
console.log("Fim do programa.")