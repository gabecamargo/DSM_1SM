numero = prompt("Entre com um número inteiro:");
numero2 = prompt("Entre com outro número inteiro:");

if (numero > numero2){
    maior = numero;

    if (maior = numero){
        menor = numero2;
    }

}else{
    maior = numero2;

    if (maior = numero2){
        menor = numero;
    }

}

console.log(maior +" é maior que "+ menor);
console.log("Fim do programa.");