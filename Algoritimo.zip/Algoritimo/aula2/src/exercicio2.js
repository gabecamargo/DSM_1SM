numero = prompt("Entre com um número inteiro:");
numero2 = prompt("Entre com outro número inteiro:");

numerofinal = parseInt(numero/numero2);

console.log(numerofinal);
console.log("Fim do programa.");