idade = prompt("Insira sua idade:")
idade = parseInt(idade);

if (idade < 18){
    console.log("de menor");
}else{
    console.log("de maior");
}
console.log("fim");

if (idade < 18){
    console.log("de menor");
}else{
    if (idade > 70){
        console.log("3 idade");
    }else{
        console.log("")
    }
    
}
console.log("fim");