numero = prompt("Entre com um número inteiro:")
numero = parseInt(numero/2);

console.log(numero);
console.log("Fim do programa.");